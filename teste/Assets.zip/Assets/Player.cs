using UnityEngine;

public class Player : MonoBehaviour
{
     public float speed = 10f;        // velocidade da nave
    public float limitX = 8f;        // limite da tela no eixo X

    void Update()
    {
        float move = Input.GetAxis("Horizontal");  // A/D ou ← →

        Vector3 position = transform.position;
        position.x += move * speed * Time.deltaTime;

        // limitar para não sair da tela
        position.x = Mathf.Clamp(position.x, -limitX, limitX);

        transform.position = position;
    }
}
